#ifndef MAIN_H
#define MAIN_H

// namespace rtsNS {
  int mainx(); //int argc, char *argv[]
// }

#endif
