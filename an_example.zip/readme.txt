Just execute the R script example.R
