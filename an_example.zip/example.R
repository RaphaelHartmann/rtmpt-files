library(rtmpt)

model <- to_rtmpt_model(mdl_file = "./2HTM_DI_g-const_g-supp.model")
model
for (t in 0:1) model <- set_resps(model = model, tree = t, categories = t*2+1, values = 1)
model

data <- to_rtmpt_data(raw_data = "./rtmpt_data.txt", model = model)
data

fit <- fit_rtmpt(model = model, data = data)
